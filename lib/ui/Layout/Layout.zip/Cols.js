import React from 'react';
import Col from './Col';


/**
 */
export default class Cols extends React.Component {


/**
 */
	render() {
		return (
			<Col {...this.props} row>
				{this.props.children}
			</Col>
		);
	};


};